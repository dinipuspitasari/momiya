<?php

namespace BookStack\Exceptions;

class SocialSignInAccountNotUsed extends SocialSignInException
{
}
