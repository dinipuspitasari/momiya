<?php

namespace BookStack\Exceptions;

class UserUpdateException extends NotifyException
{
}
