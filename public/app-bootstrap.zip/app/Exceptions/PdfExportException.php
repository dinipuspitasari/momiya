<?php

namespace BookStack\Exceptions;

class PdfExportException extends \Exception
{
}
