<?php

namespace BookStack\Access;

use Exception;

class UserInviteException extends Exception
{
    //
}
